# RenalMet — mã nguồn website

Đây là bản mẫu website tĩnh, có thể chỉnh sửa. Tệp chính là `index.html`.

## Sửa website
- Mở `index.html` bằng Visual Studio Code hoặc trình soạn thảo mã nguồn.
- Tìm các nội dung trong HTML để sửa tiêu đề, mô tả, thông tin tác giả và giao diện.
- Các phép tính nằm trong phần `<script>` ở gần cuối tệp. Hãy kiểm tra công thức và đơn vị với tài liệu gốc trước khi dùng trong nghiên cứu.

## Đưa lên GitHub Pages để quản lý bằng tài khoản của bạn
1. Tạo tài khoản GitHub bằng email của bạn nếu chưa có.
2. Tạo repository mới, ví dụ `renalmet-website`.
3. Tải `index.html` lên repository.
4. Vào **Settings → Pages**.
5. Chọn triển khai từ nhánh chính (`main`) và thư mục gốc (`/root`), rồi lưu.
6. GitHub sẽ hiển thị địa chỉ website sau khi triển khai xong. Bạn quản lý mã nguồn và cài đặt qua tài khoản GitHub của chính mình.

Tên mục và giao diện GitHub có thể thay đổi theo thời điểm.

## Lưu ý
- Đây là bản mẫu minh họa, chưa được thẩm định như phần mềm y tế.
- Không nhập dữ liệu định danh hoặc dữ liệu sức khỏe thật khi chưa có quy trình bảo mật phù hợp.
- AUC trong nghiên cứu nền thấp; không dùng các chỉ số này như công cụ chẩn đoán độc lập.
- Công thức METS-IR phải được xác minh với nguồn gốc trước khi sử dụng chính thức.
- Việc thêm dòng tên tác giả giúp ghi nhận tác giả nhưng tự nó không phải bằng chứng pháp lý đầy đủ về quyền sở hữu. Hãy giữ bản gốc, lịch sử thay đổi và các hồ sơ liên quan.
